Stella is a multi-platform Atari 2600 VCS emulator which allows you to
play all of your favourite Atari 2600 games on your PC.  You'll find the
Stella Users Manual in the docs subdirectory.  If you'd like to verify
that you have the latest release of Stella, visit the Stella Website at:

  https://stella-emu.github.io

Enjoy,

The Stella Team
